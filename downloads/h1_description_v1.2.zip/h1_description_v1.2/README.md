# H1 Description v1.2

该压缩包包含 H1 机器人的 URDF 与轻量化 STL 网格。

- URDF: `urdf/h1.urdf`
- ROS package resource name: `h1_description`
- 单位: URDF 长度为米，转动关节为弧度
- 统计: 30 个连杆，29 个关节，27 个可动关节，17 个主要可调关节

使用前请阅读 `H1_MODEL_USE_TERMS.txt`。
