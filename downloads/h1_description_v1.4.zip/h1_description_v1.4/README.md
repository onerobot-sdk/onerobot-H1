# H1 Description v1.4

该压缩包包含 H1 机器人的 URDF 与轻量化 STL 网格。

- URDF: `urdf/h1.urdf`
- ROS package resource name: `h1_description`
- 单位: URDF 长度为米，转动关节为弧度
- 统计: 46 个连杆，45 个关节，43 个可动关节，19 个主要调节控件
- 夹爪: 结构方完整模型，左右各一个联动预览控件，每个控件驱动八个连杆关节；0% 为闭合，100% 为张开

使用前请阅读 `H1_MODEL_USE_TERMS.txt`。
